import { world, system, EquipmentSlot, EntityDamageCause } from "@minecraft/server";

const ARMOR_SLOTS = [
	EquipmentSlot.Head,
	EquipmentSlot.Chest,
	EquipmentSlot.Legs,
	EquipmentSlot.Feet,
];
const XP_TABLE = {
	"minecraft:zombie": 5,
	"minecraft:zombified_piglin": 5,
	"minecraft:skeleton": 5,
	"minecraft:wither_skeleton": 5,
	"minecraft:creeper": 5,
	"minecraft:spider": 2,
	"minecraft:cave_spider": 2,
	"minecraft:enderman": 7,
	"minecraft:silverfish": 2,
	"minecraft:witch": 5,
	"minecraft:slime": 4,
	"minecraft:magma_cube": 4,
	"minecraft:giant": 5,
	"minecraft:blaze": 10,
	"minecraft:ghast": 10,
	"minecraft:piglin_brute": 9,
	"minecraft:hoglin": 3,
	"minecraft:piglin": 3,
	"minecraft:strider": 0,
	"minecraft:endermite": 5,
	"minecraft:shulker": 4,
	"minecraft:ender_dragon": 120,
	"minecraft:drowned": 3,
	"minecraft:guardian": 10,
	"minecraft:elder_guardian": 55,
	"minecraft:fish": 0,
	"minecraft:cod": 0,
	"minecraft:salmon": 0,
	"minecraft:bat": 0,
	"minecraft:villager": 0,
	"minecraft:wandering_trader": 0,
	"minecraft:ender_crystal": 0,
	"minecraft:warden": 50,
	"minecraft:allay": 0,
	"minecraft:axolotl": 0,
	"minecraft:bee": 0,
	"minecraft:camel": 0,
	"minecraft:cat": 0,
	"minecraft:chicken": 0,
	"minecraft:cow": 0,
	"minecraft:donkey": 0,
	"minecraft:fox": 0,
	"minecraft:frog": 0,
	"minecraft:goat": 0,
	"minecraft:horse": 0,
	"minecraft:llama": 0,
	"minecraft:mooshroom": 0,
	"minecraft:mule": 0,
	"minecraft:panda": 0,
	"minecraft:parrot": 0,
	"minecraft:pig": 0,
	"minecraft:polar_bear": 0,
	"minecraft:rabbit": 0,
	"minecraft:tadpole": 0,
	"minecraft:trader_llama": 0,
	"minecraft:turtle": 0,
	"minecraft:whale": 0,
};
const DRAGON_ARMOR_LORE = {
	"dragonmounts2:fire_dragonscale_lore": {
		effectsKey: "dragonmounts2:fire_dragonscale_effects",
		setKey: "dragonmounts2:fire_dragonscale_set",
		maxCd: 45.0,
		getCd: (player, _now) => player.getItemCooldown("dragonmounts2:fire_dragonscale") / 20,
	},
	"dragonmounts2:enchanted_dragonscale_lore": {
		effectsKey: "dragonmounts2:enchanted_dragonscale_effects",
		setKey: "dragonmounts2:enchanted_dragonscale_set",
		maxCd: null,
		getCd: () => 0,
	},
	"dragonmounts2:dark_dragonscale_lore": {
		effectsKey: "dragonmounts2:dark_dragonscale_effects",
		setKey: "dragonmounts2:dark_dragonscale_set",
		maxCd: 30.0,
		getCd: (player, now) => {
			const expiry = cooldowns.get(player.id)?.get("dark_dragonscale_night_heal");
			return expiry ? Math.max(0, (expiry - now) / 20) : 0;
		},
	},
	"dragonmounts2:light_dragonscale_lore": {
		effectsKey: "dragonmounts2:light_dragonscale_effects",
		setKey: "dragonmounts2:light_dragonscale_set",
		maxCd: 30.0,
		getCd: (player, now) => {
			const expiry = cooldowns.get(player.id)?.get("light_dragonscale_day_heal");
			return expiry ? Math.max(0, (expiry - now) / 20) : 0;
		},
	},
	"dragonmounts2:aether_dragonscale_lore": {
		effectsKey: "dragonmounts2:aether_dragonscale_effects",
		setKey: "dragonmounts2:aether_dragonscale_set",
		maxCd: 15.0,
		getCd: (player, now) => {
			const expiry = cooldowns.get(player.id)?.get("aether_dragonscale_sprint_speed");
			return expiry ? Math.max(0, (expiry - now) / 20) : 0;
		},
	},
	"dragonmounts2:ice_dragonscale_lore": {
		effectsKey: "dragonmounts2:ice_dragonscale_effects",
		setKey: "dragonmounts2:ice_dragonscale_set",
		maxCd: 60.0,
		getCd: (player, now) => {
			const expiry = cooldowns.get(player.id)?.get("ice_dragonscale_defensive_burst");
			return expiry ? Math.max(0, (expiry - now) / 20) : 0;
		},
	},
	"dragonmounts2:forest_dragonscale_lore": {
		effectsKey: "dragonmounts2:forest_dragonscale_effects",
		setKey: "dragonmounts2:forest_dragonscale_set",
		maxCd: 60.0,
		getCd: (player, now) => {
			const expiry = cooldowns.get(player.id)?.get("forest_dragonscale_low_health_regen");
			return expiry ? Math.max(0, (expiry - now) / 20) : 0;
		},
	},
	"dragonmounts2:ender_dragonscale_lore": {
		effectsKey: "dragonmounts2:ender_dragonscale_effects",
		setKey: "dragonmounts2:ender_dragonscale_set",
		maxCd: 60.0,
		getCd: (player, now) => {
			const expiry = cooldowns.get(player.id)?.get("ender_dragonscale_low_health_buff");
			return expiry ? Math.max(0, (expiry - now) / 20) : 0;
		},
	},
	"dragonmounts2:water_dragonscale_lore": {
		effectsKey: "dragonmounts2:water_dragonscale_effects",
		setKey: "dragonmounts2:water_dragonscale_set",
		maxCd: null,
		getCd: () => 0,
	},
	"dragonmounts2:moonlight_dragonscale_lore": {
		effectsKey: "dragonmounts2:moonlight_dragonscale_effects",
		setKey: "dragonmounts2:moonlight_dragonscale_set",
		maxCd: null,
		getCd: () => 0,
	},
	"dragonmounts2:sculk_dragonscale_lore": {
		effectsKey: "dragonmounts2:sculk_dragonscale_effects",
		setKey: "dragonmounts2:sculk_dragonscale_set",
		maxCd: null,
		getCd: () => 0,
		tiers: [
			{ threshold: 2, suffix: ".2" },
			{ threshold: 4, suffix: "" },
		],
	},
	"dragonmounts2:terra_dragonscale_lore": {
		effectsKey: "dragonmounts2:terra_dragonscale_effects",
		setKey: "dragonmounts2:terra_dragonscale_set",
		maxCd: null,
		getCd: () => 0,
	},
	"dragonmounts2:zombie_dragonscale_lore": {
		effectsKey: "dragonmounts2:zombie_dragonscale_effects",
		setKey: "dragonmounts2:zombie_dragonscale_set",
		maxCd: null,
		getCd: () => 0,
	},
	"dragonmounts2:sunlight_dragonscale_lore": {
		effectsKey: "dragonmounts2:sunlight_dragonscale_effects",
		setKey: "dragonmounts2:sunlight_dragonscale_set",
		maxCd: null,
		getCd: () => 0,
	},
	"dragonmounts2:nether_dragonscale_lore": {
		effectsKey: "dragonmounts2:nether_dragonscale_effects",
		setKey: "dragonmounts2:nether_dragonscale_set",
		maxCd: null,
		getCd: () => 0,
	},
};
const DRAGON_ARMOR_LORE_ENTRIES = Object.entries(DRAGON_ARMOR_LORE);
const cooldowns = new Map();
const pendingReflect = new Map();
const CLEANUP_INTERVAL = 1200;
let lastCleanup = 0;

world.afterEvents.playerLeave.subscribe(({ playerId }) => {
	cooldowns.delete(playerId);
	pendingReflect.delete(playerId);
});

function cleanupExpiredCooldowns(now) {
	if (now - lastCleanup < CLEANUP_INTERVAL) return;
	lastCleanup = now;

	for (const [playerId, playerCooldowns] of cooldowns) {
		for (const [key, expiry] of playerCooldowns) {
			if (expiry <= now) playerCooldowns.delete(key);
		}
		if (playerCooldowns.size === 0) cooldowns.delete(playerId);
	}
}

function isCooldownActive(playerId, key, now) {
	const expiry = cooldowns.get(playerId)?.get(key);
	return expiry !== undefined && expiry > now;
}

function setCooldown(playerId, key, seconds, now) {
	let map = cooldowns.get(playerId);
	if (!map) {
		map = new Map();
		cooldowns.set(playerId, map);
	}
	map.set(key, now + seconds * 20);
}
function isWearingFullSet(equip, componentType) {
	for (const slot of ARMOR_SLOTS) {
		if (!equip.getEquipment(slot)?.getComponent(componentType)) return false;
	}
	return true;
}

function countArmorPieces(equip, componentType) {
	let count = 0;
	for (const slot of ARMOR_SLOTS) {
		if (equip.getEquipment(slot)?.getComponent(componentType)) count++;
	}
	return count;
}
function applyDragonLoreToItem(item, fullSetMap, pieceCountMap, player, now) {
	for (const [componentId, data] of DRAGON_ARMOR_LORE_ENTRIES) {
		if (!item.getComponent(componentId)) continue;

		const lore = [];

		if (data.tiers) {
			const pieceCount = pieceCountMap.get(componentId) ?? 0;
			for (const tier of data.tiers) {
				const color = pieceCount >= tier.threshold ? "§a" : "§7";
				lore.push({ rawtext: [{ text: color, italic: false }, { translate: `tooltip.${data.setKey}.lore.set${tier.suffix}`, italic: false }] });
				lore.push({ rawtext: [{ text: "§f", italic: false }, { translate: `tooltip.${data.setKey}.lore.disc${tier.suffix}`, italic: false }] });
			}
		} else {
			const color = (fullSetMap.get(componentId) ?? false) ? "§a" : "§7";
			lore.push({ rawtext: [{ text: color, italic: false }, { translate: `tooltip.${data.setKey}.lore.set`, italic: false }] });
			lore.push({ rawtext: [{ text: "§f", italic: false }, { translate: `tooltip.${data.setKey}.lore.disc`, italic: false }] });
		}

		if (data.maxCd !== null) {
			lore.push({ rawtext: [
				{ text: "§f", italic: false },
				{ translate: "tooltip.dragonmounts2.cooldown", italic: false },
				{ text: ` ${data.maxCd.toFixed(1)}`, italic: false },
				{ translate: "tooltip.dragonmounts2.seconds", italic: false },
			] });
		}

		item.setLore(lore);
		return item;
	}
	return null;
}

function updateDragonArmorLore(player) {
	const equip = player.getComponent("minecraft:equippable");
	if (!equip) return;

	const now = system.currentTick;
	const fullSetMap = new Map();
	const pieceCountMap = new Map();

	for (const [componentId, data] of DRAGON_ARMOR_LORE_ENTRIES) {
		fullSetMap.set(componentId, isWearingFullSet(equip, data.effectsKey));
		if (data.tiers) pieceCountMap.set(componentId, countArmorPieces(equip, data.effectsKey));
	}

	for (const slot of ARMOR_SLOTS) {
		const item = equip.getEquipment(slot);
		if (!item) continue;
		const modified = applyDragonLoreToItem(item, fullSetMap, pieceCountMap, player, now);
		if (modified) equip.setEquipment(slot, modified);
	}

	const mainhand = equip.getEquipment(EquipmentSlot.Mainhand);
	if (mainhand) {
		const modified = applyDragonLoreToItem(mainhand, fullSetMap, pieceCountMap, player, now);
		if (modified) equip.setEquipment(EquipmentSlot.Mainhand, modified);
	}

	const container = player.getComponent("minecraft:inventory")?.container;
	if (!container) return;

	for (let i = 0; i < container.size; i++) {
		const item = container.getItem(i);
		if (!item) continue;
		const modified = applyDragonLoreToItem(item, fullSetMap, pieceCountMap, player, now);
		if (modified) container.setItem(i, modified);
	}
}
function applyAoeKnockback(hurtEntity, playerId, radius, knockbackStrength, applyEffect) {
	const origin = hurtEntity.location;
	const nearbyEntities = hurtEntity.dimension.getEntities({
		location: origin,
		maxDistance: radius,
	});

	for (const entity of nearbyEntities) {
		if (!entity.isValid || entity.id === hurtEntity.id) continue;

		const tameable = entity.getComponent("minecraft:tameable");
		if (tameable?.isTamed && tameable.tamedToPlayerId === playerId) continue;

		try {
			const dx = entity.location.x - origin.x;
			const dz = entity.location.z - origin.z;
			const distance = Math.sqrt(dx * dx + dz * dz);

			if (distance > 0) {
				const velocity = entity.getVelocity();
				entity.applyImpulse({
					x: velocity.x + (dx / distance) * knockbackStrength,
					y: velocity.y + 0.4,
					z: velocity.z + (dz / distance) * knockbackStrength,
				});
			}

			applyEffect(entity);
		} catch (error) {
			console.warn(`AoE effect failed on entity: ${error}`);
		}
	}
}
function isNight(timeOfDay) {
	return timeOfDay >= 12000 && timeOfDay < 24000;
}

function isDay(timeOfDay) {
	return timeOfDay >= 0 && timeOfDay < 12000;
}

world.beforeEvents.entityHurt.subscribe(event => {
	if (event.damageSource.cause !== EntityDamageCause.sonicBoom) return;
	if (event.hurtEntity.typeId !== "minecraft:player") return;

	const equip = event.hurtEntity.getComponent("minecraft:equippable");
	if (!equip) return;

	const pieces = countArmorPieces(equip, "dragonmounts2:sculk_dragonscale_effects");
	if (pieces < 2) return;
	if (pieces >= 4) pendingReflect.set(event.hurtEntity.id, event.damage);

	event.damage *= 0.75;
});

world.afterEvents.entityHurt.subscribe(event => {
	const { hurtEntity, damageSource, damage } = event;
	if (hurtEntity.typeId !== "minecraft:player") return;

	const equip = hurtEntity.getComponent("minecraft:equippable");
	if (!equip) return;

	const playerId = hurtEntity.id;
	const now = system.currentTick;
	const cause = damageSource.cause;
	if (
		cause === EntityDamageCause.fireTick ||
		cause === EntityDamageCause.fire ||
		cause === EntityDamageCause.lava
	) {
		if (
			isWearingFullSet(equip, "dragonmounts2:fire_dragonscale_effects") &&
			hurtEntity.getItemCooldown("dragonmounts2:fire_dragonscale") === 0
		) {
			hurtEntity.addEffect("fire_resistance", 30 * 20, { amplifier: 0, showParticles: true });
			hurtEntity.startItemCooldown("dragonmounts2:fire_dragonscale", 45.0 * 20);
			system.run(() => updateDragonArmorLore(hurtEntity));
		}
		return;
	}
	if (
		isWearingFullSet(equip, "dragonmounts2:ice_dragonscale_effects") &&
		!isCooldownActive(playerId, "ice_dragonscale_defensive_burst", now) &&
		damageSource.damagingEntity?.isValid
	) {
		let affected = 0;
		applyAoeKnockback(hurtEntity, playerId, 5, 1.5, entity => {
			entity.addEffect("slowness", 10 * 20, { amplifier: 1, showParticles: true });
			entity.applyDamage(1, { cause: EntityDamageCause.magic, damagingEntity: hurtEntity });
			affected++;
		});
		if (affected > 0) {
			setCooldown(playerId, "ice_dragonscale_defensive_burst", 60.0, now);
			system.run(() => updateDragonArmorLore(hurtEntity));
		}
	}
	if (
		isWearingFullSet(equip, "dragonmounts2:nether_dragonscale_effects") &&
		damageSource.damagingEntity?.isValid
	) {
		applyAoeKnockback(hurtEntity, playerId, 5, 1.5, entity => {
			entity.setOnFire(10, true);
		});
	}
	if (
		cause === EntityDamageCause.sonicBoom &&
		isWearingFullSet(equip, "dragonmounts2:sculk_dragonscale_effects")
	) {
		const attacker = damageSource.damagingEntity;
		if (!attacker?.isValid) return;

		const originalDamage = pendingReflect.get(playerId);
		pendingReflect.delete(playerId);

		try {
			attacker.applyDamage((originalDamage ?? damage) * 0.75, {
				cause: EntityDamageCause.magic,
				damagingEntity: hurtEntity,
			});
		} catch (error) {
			console.warn(`Sculk dragonscale reflect failed: ${error}`);
		}
	}
});


system.runInterval(() => {
	const now = system.currentTick;
	cleanupExpiredCooldowns(now);

	const timeOfDay = world.getTimeOfDay();
	const night = isNight(timeOfDay);
	const day = isDay(timeOfDay);

	for (const player of world.getPlayers()) {
		const equip = player.getComponent("minecraft:equippable");
		if (!equip) continue;

		const playerId = player.id;
		if (
			night &&
			isWearingFullSet(equip, "dragonmounts2:dark_dragonscale_effects") &&
			!isCooldownActive(playerId, "dark_dragonscale_night_heal", now)
		) {
			player.addEffect("regeneration", 10 * 20, { amplifier: 0, showParticles: true });
			setCooldown(playerId, "dark_dragonscale_night_heal", 30.0, now);
			updateDragonArmorLore(player);
		}
		if (
			day &&
			isWearingFullSet(equip, "dragonmounts2:light_dragonscale_effects") &&
			!isCooldownActive(playerId, "light_dragonscale_day_heal", now)
		) {
			player.addEffect("regeneration", 10 * 20, { amplifier: 0, showParticles: true });
			setCooldown(playerId, "light_dragonscale_day_heal", 30.0, now);
			updateDragonArmorLore(player);
		}

		// Zombie Dragonscale — strength at night
		if (night && isWearingFullSet(equip, "dragonmounts2:zombie_dragonscale_effects")) {
			player.addEffect("strength", 15 * 20, { amplifier: 0, showParticles: true });
		}

		const healthComp = player.getComponent("minecraft:health");
		if (healthComp) {
			const health = healthComp.currentValue;
			const halfHealth = (healthComp.maxValue || 20) / 2;
			if (
				health < halfHealth &&
				isWearingFullSet(equip, "dragonmounts2:forest_dragonscale_effects") &&
				!isCooldownActive(playerId, "forest_dragonscale_low_health_regen", now)
			) {
				player.addEffect("regeneration", 10 * 20, { amplifier: 1, showParticles: true });
				setCooldown(playerId, "forest_dragonscale_low_health_regen", 60.0, now);
				updateDragonArmorLore(player);
			}

			// Ender Dragonscale — resistance + strength when low health
			if (
				health < halfHealth &&
				isWearingFullSet(equip, "dragonmounts2:ender_dragonscale_effects") &&
				!isCooldownActive(playerId, "ender_dragonscale_low_health_buff", now)
			) {
				player.addEffect("resistance", 30 * 20, { amplifier: 2, showParticles: true });
				player.addEffect("strength", 15 * 20, { amplifier: 1, showParticles: true });
				setCooldown(playerId, "ender_dragonscale_low_health_buff", 60.0, now);
				updateDragonArmorLore(player);
			}
		}
		if (player.isInWater && isWearingFullSet(equip, "dragonmounts2:water_dragonscale_effects")) {
			player.addEffect("water_breathing", 30 * 20, { amplifier: 0, showParticles: true });
		}
		if (isWearingFullSet(equip, "dragonmounts2:sunlight_dragonscale_effects")) {
			const hungerComp = player.getComponent("minecraft:hunger");
			if (hungerComp?.hunger < 6) {
				player.addEffect("saturation", 10 * 20, { amplifier: 0, showParticles: true });
			}
		}
		if (isWearingFullSet(equip, "dragonmounts2:moonlight_dragonscale_effects")) {
			player.addEffect("night_vision", 30 * 20, { amplifier: 0, showParticles: false });
		}
		if (isWearingFullSet(equip, "dragonmounts2:terra_dragonscale_effects")) {
			player.addEffect("haste", 30 * 20, { amplifier: 0, showParticles: true });
		}

		updateDragonArmorLore(player);
	}
}, 20);
system.runInterval(() => {
	const now = system.currentTick;

	for (const player of world.getPlayers()) {
		if (!player.isSprinting) continue;

		const equip = player.getComponent("minecraft:equippable");
		if (!equip) continue;
		if (
			isWearingFullSet(equip, "dragonmounts2:aether_dragonscale_effects") &&
			!isCooldownActive(player.id, "aether_dragonscale_sprint_speed", now)
		) {
			player.addEffect("speed", 5 * 20, { amplifier: 1, showParticles: true });
			setCooldown(player.id, "aether_dragonscale_sprint_speed", 15.0, now);
			updateDragonArmorLore(player);
		}
	}
}, 10);