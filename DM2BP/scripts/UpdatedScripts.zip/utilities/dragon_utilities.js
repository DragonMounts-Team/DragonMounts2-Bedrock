import { world, system, Player } from "@minecraft/server";
import * as dragonArrays from "../arrays/dragon_arrays.js";

export const dragonTypes = { families: ["dragon"] };
const jumpData = new Map();
const CLEANUP_INTERVAL = 600;
let lastCleanup = 0;
export function getPersistentId(entity) {
	if (!entity?.isValid) return null;
	let pid = entity.getDynamicProperty("dragonmounts2:persistent_id");
	if (!pid) {
		pid = `${entity.typeId}_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
		entity.setDynamicProperty("dragonmounts2:persistent_id", pid);
	}
	return pid;
}
export function dragonsMainComponents(dragon) {
	if (!dragon?.isValid) return;
	const dragonOnList = dragonArrays.dragonTypesList.includes(dragon.typeId);
	if (!dragonOnList) return;
	const isBreathing = dragon.getProperty("dragonmounts2:is_breathing");
	const rideable = dragon.getComponent("rideable");
	const tameable = dragon.getComponent("minecraft:tameable");
	
	if (tameable?.isTamed) {
		const ownerName = tameable.tamedToPlayer?.name ?? "Unknown";
		const ownerIdentifier = tameable.tamedToPlayerId ?? "";
		dragon.setDynamicProperty("dragonmounts2:owner_name", ownerName);
		dragon.setDynamicProperty("dragonmounts2:owner_identifier", ownerIdentifier);
	}
	if (!rideable) return;
	const riders = rideable.getRiders();
	if (!riders || riders.length === 0) {
		if (isBreathing) dragon.setProperty("dragonmounts2:is_breathing", false);
		return;
	}
	const controllingSeat = rideable.controllingSeat;
	const controllingRider = riders[controllingSeat];
	if (!controllingRider || !(controllingRider instanceof Player)) return;
	
	handleDragonJumpInput(dragon, controllingRider, isBreathing);
	cleanupOldJumpData();
}
function cleanupOldJumpData() {
	const now = system.currentTick;
	if (now - lastCleanup < CLEANUP_INTERVAL) return;
	lastCleanup = now;
	for (const [id, data] of jumpData.entries()) {
		if (now - data.lastJumpTick > CLEANUP_INTERVAL * 2) {
			jumpData.delete(id);
		}
	}
}
function handleDragonJumpInput(dragon, player, isBreathing) {
	const id = player.id;
	const currentTick = system.currentTick;
	let data = jumpData.get(id);
	
	if (!data) {
		data = {
			wasJumping: false,
			holdTime: 0,
			lastJumpTick: 0,
			pendingSingle: false
		};
	}
	const isJumping = player.isJumping;
	const doubleTapWindow = 10;
	const holdThreshold = 5;
	if (isJumping && !data.wasJumping) {
		const timeSinceLastJump = currentTick - data.lastJumpTick;
		if (timeSinceLastJump < doubleTapWindow) {
			if (dragon.isOnGround) dragon.applyImpulse({x:0, y:0.75, z:0});
			data.pendingSingle = false;
		} else {
			data.pendingSingle = true;
		}
		data.lastJumpTick = currentTick;
	}
	if (isJumping) {
		data.holdTime++;
		if (data.holdTime >= holdThreshold && !isBreathing) {
			dragon.setProperty("dragonmounts2:is_breathing", true);
		}
	} else {
		if (isBreathing) dragon.setProperty("dragonmounts2:is_breathing", false);
		data.holdTime = 0;
	}
	if (data.pendingSingle && currentTick - data.lastJumpTick > Math.max(holdThreshold, doubleTapWindow)) {
		data.pendingSingle = false;
	}
	data.wasJumping = isJumping;
	jumpData.set(id, data);
}