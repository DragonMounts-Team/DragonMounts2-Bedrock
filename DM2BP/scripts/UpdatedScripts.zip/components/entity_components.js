import { world, system } from "@minecraft/server";
import * as defaultWorldArrays from "../arrays/default_world_arrays.js";
import * as entityData from "../data/entity_data.js";
import * as entityUtilities from "../utilities/entity_utilities.js";

const EGG_CHECK_INTERVAL = 10;

system.runInterval(() => {
	for (const dim of defaultWorldArrays.addonDimensions) {
		const dimension = world.getDimension(dim);
		const dragonEggs = dimension.getEntities({ families: ["dragonmounts2", "dragon_egg"] });
		for (const dragonEgg of dragonEggs) {
			if (!dragonEgg.isValid) continue;
			entityUtilities.getDragonEggNestingBlock(dragonEgg);
			entityUtilities.getDragonEggConvertBlock(dragonEgg);
		}
	}
}, EGG_CHECK_INTERVAL);

world.afterEvents.dataDrivenEntityTrigger.subscribe(({ entity, eventId }) => {
	if (!entity?.isValid) return;
	if (!entityData.dragonEggTypes[entity.typeId]) return;
	if (eventId !== "minecraft:dragon_egg_to_block") return;

	const centerBlock = entity.dimension.getBlock(entity.location);
	if (!centerBlock || (!centerBlock.isAir && !centerBlock.isLiquid)) return;

	centerBlock.setType(entity.typeId);
	entity.triggerEvent("minecraft:dragon_egg_despawn");
});