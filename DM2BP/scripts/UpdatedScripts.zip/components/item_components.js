import { world, system, ItemStack } from "@minecraft/server";
import * as defaultWorldArrays from "../arrays/default_world_arrays.js";
import * as itemData from "../data/item_data.js";
import * as itemUtilities from "../utilities/item_utilities.js";

system.beforeEvents.startup.subscribe(({itemComponentRegistry}) => {
    itemComponentRegistry.registerCustomComponent("dragonmounts2:dragon_flute", DragonFlute);
    itemComponentRegistry.registerCustomComponent("dragonmounts2:dragon_scepter", DragonScepter);
    itemComponentRegistry.registerCustomComponent("dragonmounts2:dragon_amulet", DragonAmulet);
    itemComponentRegistry.registerCustomComponent("dragonmounts2:aether_dragonscale_effects", AetherDragonscaleEffects);
    itemComponentRegistry.registerCustomComponent("dragonmounts2:fire_dragonscale_effects", FireDragonscaleEffects);
    itemComponentRegistry.registerCustomComponent("dragonmounts2:ice_dragonscale_effects", IceDragonscaleEffects);
    itemComponentRegistry.registerCustomComponent("dragonmounts2:forest_dragonscale_effects", ForestDragonscaleEffects);
    itemComponentRegistry.registerCustomComponent("dragonmounts2:ender_dragonscale_effects", EnderDragonscaleEffects);
    itemComponentRegistry.registerCustomComponent("dragonmounts2:dark_dragonscale_effects", DarkDragonscaleEffects);
    itemComponentRegistry.registerCustomComponent("dragonmounts2:light_dragonscale_effects", LightDragonscaleEffects);
    itemComponentRegistry.registerCustomComponent("dragonmounts2:enchanted_dragonscale_effects", EnchantedDragonscaleEffects);
    itemComponentRegistry.registerCustomComponent("dragonmounts2:water_dragonscale_effects", WaterDragonscaleEffects);
    itemComponentRegistry.registerCustomComponent("dragonmounts2:moonlight_dragonscale_effects", MoonlightDragonscaleEffects);
    itemComponentRegistry.registerCustomComponent("dragonmounts2:sculk_dragonscale_effects", SculkDragonscaleEffects);
    itemComponentRegistry.registerCustomComponent("dragonmounts2:terra_dragonscale_effects", TerraDragonscaleEffects);
    itemComponentRegistry.registerCustomComponent("dragonmounts2:zombie_dragonscale_effects", ZombieDragonscaleEffects);
    itemComponentRegistry.registerCustomComponent("dragonmounts2:sunlight_dragonscale_effects", SunlightDragonscaleEffects);
    itemComponentRegistry.registerCustomComponent("dragonmounts2:nether_dragonscale_effects", NetherDragonscaleEffects);
    itemComponentRegistry.registerCustomComponent("dragonmounts2:fire_dragonscale_lore", FireDragonscaleLore);
    itemComponentRegistry.registerCustomComponent("dragonmounts2:ice_dragonscale_lore", IceDragonscaleLore);
    itemComponentRegistry.registerCustomComponent("dragonmounts2:forest_dragonscale_lore", ForestDragonscaleLore);
    itemComponentRegistry.registerCustomComponent("dragonmounts2:ender_dragonscale_lore", EnderDragonscaleLore);
    itemComponentRegistry.registerCustomComponent("dragonmounts2:enchanted_dragonscale_lore", EnchantedDragonscaleLore);
    itemComponentRegistry.registerCustomComponent("dragonmounts2:dark_dragonscale_lore", DarkDragonscaleLore);
    itemComponentRegistry.registerCustomComponent("dragonmounts2:light_dragonscale_lore", LightDragonscaleLore);
    itemComponentRegistry.registerCustomComponent("dragonmounts2:aether_dragonscale_lore", AetherDragonscaleLore);
    itemComponentRegistry.registerCustomComponent("dragonmounts2:water_dragonscale_lore", WaterDragonscaleLore);
    itemComponentRegistry.registerCustomComponent("dragonmounts2:moonlight_dragonscale_lore", MoonlightDragonscaleLore);
    itemComponentRegistry.registerCustomComponent("dragonmounts2:sculk_dragonscale_lore", SculkDragonscaleLore);
    itemComponentRegistry.registerCustomComponent("dragonmounts2:terra_dragonscale_lore", TerraDragonscaleLore);
    itemComponentRegistry.registerCustomComponent("dragonmounts2:zombie_dragonscale_lore", ZombieDragonscaleLore);
    itemComponentRegistry.registerCustomComponent("dragonmounts2:sunlight_dragonscale_lore", SunlightDragonscaleLore);
    itemComponentRegistry.registerCustomComponent("dragonmounts2:nether_dragonscale_lore", NetherDragonscaleLore);
    itemComponentRegistry.registerCustomComponent("dragonmounts2:dragonscale_shield", DragonScaleShield);
});
const DragonFlute = {
    onHitEntity({attackingEntity,hitEntity,itemStack},{params}) {
        itemUtilities.dragonFluteHitEntity(attackingEntity,hitEntity,itemStack,params);
    },
    onUse({itemStack,source},{params}) {
        itemUtilities.dragonFluteUse(itemStack,source,params);
    }
};

const DragonScepter = {
    onCompleteUse({itemStack,source},{params}) {
        itemUtilities.dragonScepterCompleteUse(itemStack,source,params);
    },
    onUse({itemStack,source},{params}) {
        itemUtilities.dragonScepterUse(itemStack,source,params);
    }
};

const DragonAmulet = {
    onHitEntity({attackingEntity,hitEntity,itemStack},{params}) {
        itemUtilities.dragonAmuletHitEntity(attackingEntity,hitEntity,itemStack,params);
    },
    onUseOn({block,blockFace,source,itemStack},{params}) {
        itemUtilities.dragonAmuletUseOn(source,block,blockFace,itemStack,params);
    }
};

const DragonScaleShield = {};

const AetherDragonscaleEffects = {};
const FireDragonscaleEffects = {};
const IceDragonscaleEffects = {};
const EnderDragonscaleEffects = {};
const ForestDragonscaleEffects = {};
const DarkDragonscaleEffects = {};
const LightDragonscaleEffects = {};
const EnchantedDragonscaleEffects = {};
const WaterDragonscaleEffects = {};
const MoonlightDragonscaleEffects = {};
const SculkDragonscaleEffects = {};
const TerraDragonscaleEffects = {};
const ZombieDragonscaleEffects = {};
const SunlightDragonscaleEffects = {};
const NetherDragonscaleEffects = {};

const FireDragonscaleLore = {};
const IceDragonscaleLore = {};
const EnderDragonscaleLore = {};
const ForestDragonscaleLore = {};
const EnchantedDragonscaleLore = {};
const DarkDragonscaleLore = {};
const LightDragonscaleLore = {};
const AetherDragonscaleLore = {};
const WaterDragonscaleLore = {};
const MoonlightDragonscaleLore = {};
const SculkDragonscaleLore = {};
const TerraDragonscaleLore = {};
const ZombieDragonscaleLore = {};
const SunlightDragonscaleLore = {};
const NetherDragonscaleLore = {};