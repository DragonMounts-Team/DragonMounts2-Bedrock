import { world, system, Player } from "@minecraft/server";
import { ActionFormData, ModalFormData, MessageFormData } from "@minecraft/server-ui";

/**
 * Utility functions for UI/form operations
 * Following 2.8.0 Script API patterns with proper form builders
 */

/**
 * Show a message to a player
 * @param {Player} player - The player to show the message to
 * @param {string} message - The message text
 */
export function showMessageToPlayer(player, message) {
	if (!player?.isValid) return;
	player.onScreenDisplay.setActionBar({ text: message });
}

/**
 * Show a message form to a player
 * @param {Player} player - The target player
 * @param {string} title - Form title
 * @param {string} body - Form body text
 * @param {string} button1 - First button text
 * @param {string} button2 - Second button text
 * @returns {Promise<number>} Promise resolving to button index (0 or 1)
 */
export async function showMessageForm(player, title, body, button1, button2) {
	if (!player?.isValid) return -1;
	const form = new MessageFormData()
		.title(title)
		.body(body)
		.button1(button1)
		.button2(button2);
	
	try {
		const response = await form.show(player);
		return response.selection ?? -1;
	} catch (e) {
		console.warn(`UI error for ${player.name}:`, e);
		return -1;
	}
}